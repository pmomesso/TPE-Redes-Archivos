# TuTV

Track and comment TV shows online

## Administrator credentials

* Mail address: noreplytutv@gmail.com
* Password: cm7nsSf1K

## Built With

* [Spring Web MVC​](https://spring.io/) - Web framework
* [Hibernate](https://hibernate.org/) and [JPA](https://www.oracle.com/technetwork/java/javaee/tech/persistence-jsp-140049.html) - Persistence
* [Maven](https://maven.apache.org/) - Dependency Management
* [PostgreSQL](https://www.postgresql.org/) - Database
* [GIT](https://www.git-scm.com/) - Code versioning


## Authors

* **Agustina Osimani** - [agusosimani](https://github.com/agusosimani)
* **Pedro Momesso** - [pmomesso](https://github.com/pmomesso)
* **Franco Baliarda** - [fbaliarda](https://github.com/fbaliarda)
* **Nicolas Barrera** - [atharos1](https://github.com/atharos1)

