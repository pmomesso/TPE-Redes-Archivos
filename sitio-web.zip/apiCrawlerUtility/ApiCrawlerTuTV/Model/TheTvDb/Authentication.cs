﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApiCrawlerTuTV.Model.TheTvDb {
    public class Authentication {
        public string ApiKey { get; set; }
        public string UserName { get; set; }
        public string UserKey { get; set; }
    }
}
