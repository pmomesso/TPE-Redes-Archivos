package ar.edu.itba.paw.model.errors;

public enum Errors {
    USERNAME_ALREADY_IN_USE,
    MAIL_ALREADY_IN_USE;

}
